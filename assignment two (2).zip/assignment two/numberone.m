%%GROUP 7 MATLAB ASSIGNMENT ONE
%reading an excell sheet into matlab
MS = readtable("C:\Users\sseba\Desktop\assignment two\data set assignment one.xlsx");
disp(MS)
% separating data from each year into diffrent tables
MS2010 =MS(MS.year==2010, : );%extraction of unique years(2010)
MS2011 =MS(MS.year==2011, : );%extraction of unique years(2011)
MS2012 =MS(MS.year==2012, : );%extraction of unique years(2012)
MS2013 =MS(MS.year==2013, : );%extraction of unique years(2013)
MS2014 =MS(MS.year==2014, : );%extraction of unique years(2014)
MS2015 =MS(MS.year==2015, : );%extraction of unique years(2015)
MS2016 =MS(MS.year==2016, : );%extraction of unique years(2016)
MS2017 =MS(MS.year==2017, : );%extraction of unique years(2017)
MS2018 =MS(MS.year==2018, : );%extraction of unique years(2018)
MS2019 =MS(MS.year==2019, : );%extraction of unique years(2019)
MS2020 =MS(MS.year==2020, : );%extraction of unique years(2020)
MS2021 =MS(MS.year==2021, : );%extraction of unique years(2021)
MS2022 =MS(MS.year==2022, : );%extraction of unique years(2022)
MS2023 =MS(MS.year==2023, : );%extraction of unique years(2023)
MS2024 =MS(MS.year==2024, : );%extraction of unique years(2024)
MS2025 =MS(MS.year==2025, : );%extraction of unique years(2025)
%conversion of tables into struts
S2010=table2struct(MS2010);%for MS2010
S2011=table2struct(MS2011);%for MS2011
S2012=table2struct(MS2012);%for MS2012
S2013=table2struct(MS2013);%for MS2013
S2014=table2struct(MS2014);%for MS2014
S2015=table2struct(MS2015);%for MS2015
S2016=table2struct(MS2016);%for MS2016
S2017=table2struct(MS2017);%for MS2017
S2018=table2struct(MS2024);%for MS2018
S2019=table2struct(MS2024);%for MS2019
S2020=table2struct(MS2024);%for MS2020
S2021=table2struct(MS2024);%for MS2021
S2022=table2struct(MS2024);%for MS2022
S2023=table2struct(MS2024);%for MS2023
S2024=table2struct(MS2024);%for MS2024
S2025=table2struct(MS2024);%for MS2025
%Writing table into matlab
workbook = "C:\Users\sseba\Desktop\assignment two\all tables number one.xlsx";
%writing each table on adiffrent sheets
writetable(MS2010,workbook,'sheet','MS2010');
writetable(MS2011,workbook,'sheet','MS2011');
writetable(MS2012,workbook,'sheet','MS2012');
writetable(MS2013,workbook,'sheet','MS2013');
writetable(MS2014,workbook,'sheet','MS2014');
writetable(MS2015,workbook,'sheet','MS2015');
writetable(MS2016,workbook,'sheet','MS2016');
writetable(MS2017,workbook,'sheet','MS2017');
writetable(MS2018,workbook,'sheet','MS2018');
writetable(MS2019,workbook,'sheet','MS2019');
writetable(MS2020,workbook,'sheet','MS2020');
writetable(MS2021,workbook,'sheet','MS2021');
writetable(MS2022,workbook,'sheet','MS2022');
writetable(MS2023,workbook,'sheet','MS2023');
writetable(MS2024,workbook,'sheet','MS2024');
writetable(MS2025,workbook,'sheet','MS2025');
%UNEMPLOYMENT RATE 2010
figure;
Countrynames2010=MS2010.country_name(1:10:200);
Unemployment2010=MS2010.UnemploymentRate___(1:10:200);
bar(categorical(Countrynames2010),Unemployment2010,'r');
xlabel('COUNTRIES');
ylabel('UNEMPLOYMENT RATE');
title('A BAR GRAPH SHOWING UNEMPLOYMENT RATE OF RANDOM COUNTRIES IN 2010'),
%UNEMPLOYMENT RATE 2011
figure;
Countrynames2011=MS2011.country_name(1:10:200);
Unemployment2011=MS2011.UnemploymentRate___(1:10:200);
barh(categorical(Countrynames2011),Unemployment2011,'g');
ylabel('COUNTRIES');
xlabel('UNEMPLOYMENT RATE');
title('A BAR GRAPH SHOWING UNEMPLOYMENT RATE OF RANDOM COUNTRIES IN 2011'),
%2012 inflation cpl against gdp current
figure;
T=table(MS2012.country_name(1:10:200),MS2012.Inflation_CPI__(1:10:200),MS2012.GDP_CurrentUSD_(1:10:200),'VariableNames',{'countrynames','inflation','GDP_Current'});
scatter(T.inflation,T.GDP_Current,'k*');
xlabel('INFLATION 2012');
ylabel('GDP CURRENT 2012');
title('A SCATTER GRAPH OF INFLATION AGAINST GDP 2012');
ylim([-1e12,4e12]);

%2013 government expense sample
T2013=table(MS2013.country_name(17:24),MS2013.GovernmentExpense__OfGDP_(17:24),'VariableNames',{'countrynames','governmentexp'});
T2013sorted=sortrows(T2013,'governmentexp','descend');
figure;
pareto(T2013sorted.governmentexp,T2013sorted.countrynames);
xlabel('COUNTRIES');
ylabel('GOVERNMENT EXPENDIURE');
title('A PARETO CHART SOWING GOVT EXPENDITURE IN 2013 FOR SELECTED COUNTRIES')

% %2014 GOVERNMENT REVENUE
T2014=table(MS2014.country_name(1:5:200),MS2014.GovernmentRevenue__OfGDP_(1:5:200),'VariableNames',{'countrynames','government_revenue'});
figure;
histogram(T2014.government_revenue);
ylabel('GOVERNMENT REVENUE');

%2015 GDP 
figure;
boxplot(MS2015.GDPPerCapita_CurrentUSD_);
grid on;
title('BOX PLOT REPRESENTING GDP PER CAPITAL');

%2016 PIECHART
T2016=table(MS2016.country_name(1:10:200),MS2016.UnemploymentRate___(1:10:200),'VariableNames',{'countrynames','UnemploymentRate'});
Finite_idx=isfinite(T2016.UnemploymentRate);
fincountry=T2016.countrynames(Finite_idx);
finemp=T2016.UnemploymentRate(Finite_idx);
figure;
pie(finemp,fincountry);
title('A PIE CHART SHOWING UNEMPLOYMENT RATE OF 2016');
legend;

%2017 CATEGORIZATION
T2017=table(MS2017.country_name(1:10:200),MS2017.UnemploymentRate___(1:10:200),MS2017.GovernmentExpense__OfGDP_(1:10:200),'VariableNames',{'countrynames','UnemploymentRate','Governmentexp'});
[X, Y]=meshgrid(T2017.UnemploymentRate,T2017.Governmentexp);
figure;
Z=X.^2+Y.^2;
surf(X,Y,Z);
xlabel('UNEMPLOYMENT RATE');
ylabel('GOVERNMENT EXPENDITURE');
title('RELATIONSHIP OF THE SQUARES OF UNEMPLOYMENT RATE AND GOVERNMENT EXPENDITURE');

%UNEMPLOYMENT RATE 2018
figure;
heatmap(MS2018.UnemploymentRate___(1:10:200));
title('HEATMAP OF UNEMPLOYMENT RATE OF 2018');

%2017 CATEGORIZATION
T2017=table(MS2017.country_name(1:10:200),MS2017.UnemploymentRate___(1:10:200),MS2017.GovernmentExpense__OfGDP_(1:10:200),'VariableNames',{'countrynames','UnemploymentRate','Governmentexp'});
[X, Y]=meshgrid(T2017.UnemploymentRate,T2017.Governmentexp);
figure;
Z=X.^2+Y.^2;
surfc(X,Y,Z);
xlabel('UNEMPLOYMENT RATE');
ylabel('GOVERNMENT EXPENDITURE');
title('RELATIONSHIP OF THE SQUARES OF UNEMPLOYMENT RATE AND GOVERNMENT EXPENDITURE');

%2018 unemployment
figure;
M=(MS2018.UnemploymentRate___);
[A B C]=meshgrid(M);
u=sin(A);
v=sin(B);
w=C;
quiver3(A,B,C,u,v,w,'r');
title('3D QUIVER PLOT');
%2019 unemployment
figure;
F=MS2019.UnemploymentRate___;
y1=sin(F);
z1=cos(F);
stem3(F,y1,z1,'g');
title('3D STEM PLOT');

for n=1:12
     names=['figure' num2str(n) '.jpg ']
     saveas(figure(n), names);
end

